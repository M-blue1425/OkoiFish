<?php

	class defaults extends load{

		function home(){

			return "Hello World";

		}
	
	}

?>
