<?php
	
	class data_model extends load{

		function __construct(){

			// statement

		}

	}